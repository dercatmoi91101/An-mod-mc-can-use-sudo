package com.example.sudoboss;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import sub.pls.item.KingdomBreakerTntItem;
import sub.pls.item.MinimizedBoxWeapon;
import sub.pls.networking.InventorySyncNetworking;

public class SudoBossMod implements ModInitializer {
    public static final String MOD_ID = "subpls";

    public static final class_1792 KINGDOM_BREAKER_TNT = class_2378.method_10230(
        class_7923.field_41178,
        class_2960.method_60655(MOD_ID, "kingdom_breaker_tnt"),
        new KingdomBreakerTntItem(new class_1792.class_1793())
    );

    public static final class_1792 MINIMIZED_BOX_WEAPON = class_2378.method_10230(
        class_7923.field_41178,
        class_2960.method_60655(MOD_ID, "minimized_box_weapon"),
        new MinimizedBoxWeapon(new class_1792.class_1793())
    );

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(InventorySyncNetworking.ID, InventorySyncNetworking.CODEC);
        InventorySyncNetworking.registerServerReceivers();
    }
}
