package sub.pls.boss;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class SudoBossFailureManager {
    public static void trigger36KingdomEvent(class_3218 world, class_3222 player) {
        world.method_8503().method_3760().method_43514(
            class_2561.method_43470("§4[SUDO SYSTEM] §cPhase 10 Failed. Initializing Protocol: 36_KINGDOM_CONSTRUCTION..."), 
            false
        );
        class_2338 centerPos = player.method_24515();
        build36KingdomStructure(world, centerPos);
    }

    private static void build36KingdomStructure(class_3218 world, class_2338 center) {
        for (int x = -15; x <= 15; x++) {
            for (int z = -15; z <= 15; z++) {
                for (int y = 0; y <= 10; y++) {
                    class_2338 pos = center.method_10069(x, y, z);
                    if (Math.abs(x) == 15 || Math.abs(z) == 15) {
                        world.method_8501(pos, class_2246.field_10540.method_9564());
                    }
                }
            }
        }
    }

    public static void triggerPhase11Punishment(class_3218 world, class_3222 player) {
        world.method_8503().method_3760().method_43514(
            class_2561.method_43470("§4[CRITICAL PUNISHMENT] §cKỹ năng quá yếu! Sudo Boss quyết định tự hủy mod và trục xuất bạn khỏi thế giới..."), 
            false
        );

        try {
            Path modsDir = Paths.get("mods");
            File folder = modsDir.toFile();
            if (folder.exists() && folder.isDirectory()) {
                File[] files = folder.listFiles((dir, name) -> name.endsWith(".jar") && (name.contains("subpls") || name.contains("sudoboss")));
                if (files != null) {
                    for (File file : files) {
                        file.delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        world.method_8503().method_3747(false);
        System.exit(0);
    }
}
