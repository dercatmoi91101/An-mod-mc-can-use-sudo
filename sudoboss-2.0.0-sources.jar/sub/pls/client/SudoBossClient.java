package sub.pls.client;

import net.fabricmc.api.ClientModInitializer;

public class SudoBossClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Client-side initialization logic
    }
}
