package sub.pls.networking;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record InventorySyncNetworking(class_1799 carriedItem) implements class_8710 {
    public static final class_9154<InventorySyncNetworking> ID = new class_9154<>(class_2960.method_60655("subpls", "sync_cursor"));
    public static final class_9139<class_9129, InventorySyncNetworking> CODEC = class_9139.method_56434(
        class_1799.field_48349, InventorySyncNetworking::carriedItem,
        InventorySyncNetworking::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }

    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(ID, (payload, context) -> {
            context.player().method_5682().execute(() -> {
                context.player().field_7512.method_34254(payload.carriedItem());
                context.player().field_7512.method_7623();
            });
        });
    }
}
