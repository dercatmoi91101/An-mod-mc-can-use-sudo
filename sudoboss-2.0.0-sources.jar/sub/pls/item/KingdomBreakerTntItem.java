package sub.pls.item;

import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;

public class KingdomBreakerTntItem extends class_1792 {
    public KingdomBreakerTntItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        var world = context.method_8045();
        var pos = context.method_8037().method_10084();
        if (!world.method_8608()) {
            world.method_8501(pos, class_2246.field_10375.method_9564());
            context.method_8036().method_7353(class_2561.method_43470("§e[!] Đã cài đặt TNT chiến thuật lên 36 Kingdom!"), true);
        }
        return class_1269.field_5812;
    }
}
