package sub.pls.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class MinimizedBoxWeapon extends class_1792 {
    public MinimizedBoxWeapon(class_1793 settings) {
        super(settings.method_7889(1));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        if (!world.method_8608()) {
            user.method_7353(class_2561.method_43470("§b[OS WEAPON] §fBạn đã xé cửa sổ Client thành vũ khí sát thương!"), false);
            world.method_8390(class_1309.class, user.method_5829().method_1014(10.0), entity -> entity != user)
                .forEach(target -> {
                    target.method_5643(world.method_48963().method_48831(), 500.0f);
                    target.method_6005(2.0, user.method_23317() - target.method_23317(), user.method_23321() - target.method_23321());
                });
            user.method_7357().method_7906(this, 40);
        }
        return class_1271.method_22427(itemStack);
    }
}
